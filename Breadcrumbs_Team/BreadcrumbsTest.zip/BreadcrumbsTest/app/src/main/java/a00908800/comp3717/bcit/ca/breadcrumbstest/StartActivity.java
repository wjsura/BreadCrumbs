package a00908800.comp3717.bcit.ca.breadcrumbstest;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

public class StartActivity extends FragmentActivity {

    Button startMark;
    private Spinner spinnerHour;
    private Spinner spinnerMin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        startMark = (Button)findViewById(R.id.startButton);
        addListenerOnSpinnerItemSelection();
    }

    public void addListenerOnSpinnerItemSelection(){
        spinnerHour = (Spinner)findViewById(R.id.hour_spinner);
        spinnerHour.setOnItemSelectedListener(new CustomOnItemSelectedListener());
        spinnerMin = (Spinner)findViewById(R.id.min_spinner);
        spinnerMin.setOnItemSelectedListener(new CustomOnItemSelectedListener());
    }

    public void addListenerOnButton(){
        spinnerHour = (Spinner)findViewById(R.id.hour_spinner);
        startMark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
    }

    public void start(View v){

        int hourString = Integer.parseInt(spinnerHour.getSelectedItem().toString());
        Intent intent = new Intent(this, MapsActivity.class);
        hourString *= 60;
        int minString = Integer.parseInt(spinnerMin.getSelectedItem().toString());
        int totalInt = hourString + minString;
        intent.putExtra("message", totalInt);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_start, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

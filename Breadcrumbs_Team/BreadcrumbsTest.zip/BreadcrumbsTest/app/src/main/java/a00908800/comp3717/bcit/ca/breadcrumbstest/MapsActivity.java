package a00908800.comp3717.bcit.ca.breadcrumbstest;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.Timer;
import java.util.TimerTask;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, LocationListener,
        GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener {


    private GoogleMap mMap; // Might be null if Google Play services APK is not available.
    Timer timer;
    TimerTask timerTask;
    final Handler handler = new Handler();
    TextView edit;
    TextView distance;
    private int seconds;
    private int minutes;
    private int hours;
    int totalInt;
    String minString;
    String secString;
    int i=0;

    private GoogleApiClient mGoogleApiClient;
    public static final String TAG = MapsActivity.class.getSimpleName();
    private LocationRequest mLocationRequest;
    private Location mark = null;
    private  boolean mRequestingLocationUpdates = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        edit = (TextView)findViewById(R.id.timer);
        Intent intent = getIntent();
        if(intent!=null) {
            totalInt = intent.getIntExtra("message", 0);
        }
        startTimer(edit);
        distance = (TextView)findViewById(R.id.text_distance);
        mLocationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(10 * 1000)        // 10 seconds, in milliseconds
                .setFastestInterval(1 * 1000); // 1 second, in milliseconds

        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
    }

    public void startTimer(View v){

        seconds = 0;
        minutes = 0;
        hours = 0;

        minutes = totalInt % 60;
        hours = totalInt / 60;

        timer = new Timer();
        initializeTimerTask();
        timer.schedule(timerTask, 0, 1000);
    }


    public void stopTimerTask(View v){
        AlertDialog.Builder confirmDialog = new AlertDialog.Builder(this);

        // Setting Dialog Title
        confirmDialog.setTitle("End Timer?");

        // Setting Dialog Message
        confirmDialog.setMessage("Do you want to end the timer?");

        // Setting OK Button
        confirmDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                if (timer != null) {
                    timer.cancel();
                    timer = null;
                    i = 0;
                }
                finish();
            }
        });
        confirmDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        confirmDialog.show();
    }

    public void initializeTimerTask(){
        timerTask = new TimerTask(){
            public void run(){
                handler.post(new Runnable(){
                    public void run(){
                        decrease();
                    }
                });
            }
        };
    }

    public void decrease(){
        boolean startDecrease = true;
        if (hours != 0 || minutes != 0 || seconds != 0) {
            if (minutes == 0 && seconds == 0 && hours != 0) {
                hours--;
                minutes = 60;
            }
            if (seconds == 0 && minutes != 0) {
                minutes--;
                seconds = 60;
            }
            seconds--;
            String sec = String.format("%02d", seconds);
            String mins = String.format("%02d", minutes);
            String hour = String.format("%02d", hours);
            edit.setText(hour + ":" + mins + ":" + sec);
        }
        else {
            if (i == 0) {
                AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);

                // Setting Dialog Title
                alertDialog.setTitle("Timer Done!");

                // Setting Dialog Message
                alertDialog.setMessage("Time has elapsed");

                // Setting OK Button
                alertDialog.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                Vibrator v = (Vibrator) this.getSystemService(Context.VIBRATOR_SERVICE);
                v.vibrate(2000);
                // Showing Alert Message
                alertDialog.show();
                i++;
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        setUpMapIfNeeded();
        mGoogleApiClient.connect();
        if (mGoogleApiClient.isConnected() && !mRequestingLocationUpdates) {
            startLocationUpdates();
        }
    }

    public void resetTimer(){
        seconds = 0;
        minutes = 0;
        hours = 0;

        minutes = totalInt % 60;
        hours = totalInt / 60;
    }

    private void setUpMapIfNeeded() {
        // Do a null check to confirm that we have not already instantiated the map.
        if (mMap == null) {
            // Try to obtain the map from the SupportMapFragment.
            mMap = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
                    .getMap();
            // Check if we were successful in obtaining the map.
            if (mMap != null) {
                setUpMap();
            }
        }
    }

    private void setUpMap() {
        mMap.setMyLocationEnabled(true);
        mMap.addMarker(new MarkerOptions().position(new LatLng(0, 0)).title("Marker"));
    }

    @Override
    public void onMapReady(GoogleMap map) {
    }

    @Override
    public void onLocationChanged(Location location) {
        updateUI(location);
    }

    @Override
    public void onConnected(Bundle bundle) {
        Location location = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        if (location == null) {
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, (com.google.android.gms.location.LocationListener) this);
        }
        else {
            if (mark == null) {
                mark = location;
                handleNewLocation(location);
            } else {
                handleNewLocation(mark);
            }
        }
        distance.setText(((int) location.distanceTo(mark)) + "m");
        if (mRequestingLocationUpdates) {
            startLocationUpdates();
        }
    }

    private void handleNewLocation(Location location) {
        Log.d(TAG, location.toString());

        double currentLatitude = location.getLatitude();
        double currentLongitude = location.getLongitude();
        LatLng latLng = new LatLng(currentLatitude, currentLongitude);

        MarkerOptions options = new MarkerOptions()
                .position(latLng)
                .title("New Mark");
        if (options != null) {
            mMap.addMarker(options);
        } else {
            Toast.makeText(this, "Location was not found", Toast.LENGTH_SHORT).show();
        }
        float zoomLevel = (float) 16.0;
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, zoomLevel));
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {

    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mGoogleApiClient.isConnected()) {
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, (com.google.android.gms.location.LocationListener) this);
            mGoogleApiClient.disconnect();
        }
    }

    protected void createLocationRequest() {
        LocationRequest mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(10000);
        mLocationRequest.setFastestInterval(5000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    protected void startLocationUpdates() {
        LocationServices.FusedLocationApi.requestLocationUpdates(
                mGoogleApiClient, mLocationRequest, this);
    }

    private void updateUI(Location location) {
        distance.setText(((int) location.distanceTo(mark)) + "m");
    }
}
